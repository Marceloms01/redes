# practica 2 de redes

## Lista de fallos y faltas a solucionar

<p>En este apartado se pondrán solo los errores encontrados que hay que solucionar</p>

- Añadir mensajes de error en el servidor. 
- Arreglar el Cliente para reaccionar ante el inicio de sesión.
- Añadir juego al servidor.

## Lista de fallos y faltas arregladas

<p>En este apartado se pondrán solo los errores encontrados que se han solucionado</p>

- Controlada la desconexión de jugadores.
- manejado el inicio de sesión.

